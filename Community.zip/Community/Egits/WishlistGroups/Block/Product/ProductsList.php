<?php
namespace Egits\WishlistGroups\Block\Product;

class ProductsList extends \Magento\CatalogWidget\Block\Product\ProductsList
{
}
